# ci_adminlte
Mengintegrasikan Template AdminLTE dengan Codeigniter v.3.1.5
