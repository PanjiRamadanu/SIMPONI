<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Komoditasbibit Read</h2>
        <table class="table">
	    <tr><td>IDKelompokTani</td><td><?php echo $IDKelompokTani; ?></td></tr>
	    <tr><td>NamaBibit</td><td><?php echo $NamaBibit; ?></td></tr>
	    <tr><td>Jumlah</td><td><?php echo $Jumlah; ?></td></tr>
	    <tr><td>Tahun</td><td><?php echo $Tahun; ?></td></tr>
	    <tr><td>Harga</td><td><?php echo $Harga; ?></td></tr>
	    <tr><td>Satuan</td><td><?php echo $Satuan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('c_komoditasbibit') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>