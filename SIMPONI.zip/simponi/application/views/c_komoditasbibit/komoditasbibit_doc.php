<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Komoditasbibit List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>IDKelompokTani</th>
		<th>NamaBibit</th>
		<th>Jumlah</th>
		<th>Tahun</th>
		<th>Harga</th>
		<th>Satuan</th>
		
            </tr><?php
            foreach ($c_komoditasbibit_data as $c_komoditasbibit)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $c_komoditasbibit->IDKelompokTani ?></td>
		      <td><?php echo $c_komoditasbibit->NamaBibit ?></td>
		      <td><?php echo $c_komoditasbibit->Jumlah ?></td>
		      <td><?php echo $c_komoditasbibit->Tahun ?></td>
		      <td><?php echo $c_komoditasbibit->Harga ?></td>
		      <td><?php echo $c_komoditasbibit->Satuan ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>