<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Komoditas Bibit</h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">IDKelompokTani <?php echo form_error('IDKelompokTani') ?></label>
            <input type="text" class="form-control" name="IDKelompokTani" id="IDKelompokTani" placeholder="IDKelompokTani" readonly value="<?php echo $IDKelompokTani; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">NamaBibit <?php echo form_error('NamaBibit') ?></label>
            <input type="text" class="form-control" name="NamaBibit" id="NamaBibit" placeholder="NamaBibit" value="<?php echo $NamaBibit; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Jumlah <?php echo form_error('Jumlah') ?></label>
            <input type="text" class="form-control" name="Jumlah" id="Jumlah" placeholder="Jumlah (Inputan berupa angka)" value="<?php echo $Jumlah; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Tahun <?php echo form_error('Tahun') ?></label>
            <input type="text" class="form-control" name="Tahun" id="Tahun" placeholder="Tahun (Inputan berupa angka)" value="<?php echo $Tahun; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Harga <?php echo form_error('Harga') ?></label>
            <input type="text" class="form-control" name="Harga" id="Harga" placeholder="Harga" value="<?php echo $Harga; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Satuan <?php echo form_error('Satuan') ?></label> <br>
               <select name="Satuan"> 
                <option value="Kg">Kg</option>
                <option value="Ton">Ton</option>
            </select>

            <!-- <input type="text" class="form-control" name="Satuan" id="Satuan" placeholder="Satuan" value="<?php echo $Satuan; ?>" /> -->
        </div>
	    <input type="hidden" name="IDKomoditasBibit" value="<?php echo $IDKomoditasBibit; ?>" />
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
	    <a href="<?php echo site_url('row/index3') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>
