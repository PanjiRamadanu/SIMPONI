<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Wilayah List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>IDKomoditasBibit</th>
		<th>IDKelompokTani</th>
		<th>Kepemilikan</th>
		<th>Alamat</th>
		<th>Tahun</th>
		<th>Luas</th>
		<th>Satuan</th>
		
            </tr><?php
            foreach ($c_wilayah_data as $c_wilayah)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $c_wilayah->IDKomoditasBibit ?></td>
		      <td><?php echo $c_wilayah->IDKelompokTani ?></td>
		      <td><?php echo $c_wilayah->Kepemilikan ?></td>
		      <td><?php echo $c_wilayah->Alamat ?></td>
		      <td><?php echo $c_wilayah->Tahun ?></td>
		      <td><?php echo $c_wilayah->Luas ?></td>
		      <td><?php echo $c_wilayah->Satuan ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>