<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Wilayah</h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">IDKomoditasBibit </label>
            <input type="text" class="form-control" name="IDKomoditasBibit" id="IDKomoditasBibit" placeholder="IDKomoditasBibit" readonly value="<?php echo $IDKomoditasBibit; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">IDKelompokTani </label>
            <input type="text" class="form-control" name="IDKelompokTani" id="IDKelompokTani" placeholder="IDKelompokTani" readonly value="<?php echo $IDKelompokTani; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Kepemilikan <?php echo form_error('Kepemilikan') ?></label>
            <input type="text" class="form-control" name="Kepemilikan" id="Kepemilikan" placeholder="Kepemilikan" value="<?php echo $Kepemilikan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Alamat <?php echo form_error('Alamat') ?></label>
            <input type="text" class="form-control" name="Alamat" id="Alamat" placeholder="Alamat" value="<?php echo $Alamat; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Tahun <?php echo form_error('Tahun') ?></label>
            <input type="text" class="form-control" name="Tahun" id="Tahun" placeholder="Tahun" value="<?php echo $Tahun; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Luas <?php echo form_error('Luas') ?></label>
            <input type="text" class="form-control" name="Luas" id="Luas" placeholder="Luas" value="<?php echo $Luas; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Satuan <?php echo form_error('Satuan') ?></label>
            <input type="text" class="form-control" name="Satuan" id="Satuan" placeholder="Satuan" value="<?php echo $Satuan; ?>" />
        </div>
        <input type="hidden" name="IDWilayah" value="<?php echo $IDWilayah; ?>" />
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
	    <a href="<?php echo site_url('row/index6') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>
