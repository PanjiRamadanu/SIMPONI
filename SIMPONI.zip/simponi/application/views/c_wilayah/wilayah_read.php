<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Wilayah Read</h2>
        <table class="table">
	    <tr><td>IDKomoditasBibit</td><td><?php echo $IDKomoditasBibit; ?></td></tr>
	    <tr><td>IDKelompokTani</td><td><?php echo $IDKelompokTani; ?></td></tr>
	    <tr><td>Kepemilikan</td><td><?php echo $Kepemilikan; ?></td></tr>
	    <tr><td>Alamat</td><td><?php echo $Alamat; ?></td></tr>
	    <tr><td>Tahun</td><td><?php echo $Tahun; ?></td></tr>
	    <tr><td>Luas</td><td><?php echo $Luas; ?></td></tr>
	    <tr><td>Satuan</td><td><?php echo $Satuan; ?></td></tr>
	    <!-- <tr><td></td><td><a href="<?php echo site_url('c_wilayah') ?>" class="btn btn-default">Cancel</a></td></tr> -->
	</table>
        </body>
</html>