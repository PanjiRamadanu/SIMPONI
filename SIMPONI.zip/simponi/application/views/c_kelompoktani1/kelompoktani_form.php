<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Kelompok Tani</h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">NamaKelompokTani <?php echo form_error('NamaKelompokTani') ?></label>
            <input type="text" class="form-control" name="NamaKelompokTani" id="NamaKelompokTani" placeholder="Nama Kelompok Tani" value="<?php echo $NamaKelompokTani; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Alamat <?php echo form_error('Alamat') ?></label>
            <input type="text" class="form-control" name="Alamat" id="Alamat" placeholder="Alamat" value="<?php echo $Alamat; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">RT <?php echo form_error('RT') ?></label>
            <input type="text" class="form-control" name="RT" id="RT" placeholder="RT (Isikan inputan berupa angka" value="<?php echo $RT; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Kelurahan <?php echo form_error('Kelurahan') ?></label>
            <input type="text" class="form-control" name="Kelurahan" id="Kelurahan" placeholder="Kelurahan" value="<?php echo $Kelurahan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Kecamatan <?php echo form_error('Kecamatan') ?></label>
            <input type="text" class="form-control" name="Kecamatan" id="Kecamatan" placeholder="Kecamatan" value="<?php echo $Kecamatan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Ketua <?php echo form_error('Ketua') ?></label>
            <input type="text" class="form-control" name="Ketua" id="Ketua" placeholder="Ketua" value="<?php echo $Ketua; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">JumlahAnggota <?php echo form_error('JumlahAnggota') ?></label>
            <input type="text" class="form-control" name="JumlahAnggota" id="JumlahAnggota" placeholder="Jumlah Anggota (Isikan inputan berupa angka)" value="<?php echo $JumlahAnggota; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">TahunBerdiri <?php echo form_error('TahunBerdiri') ?></label>
            <input type="text" class="form-control" name="TahunBerdiri" id="TahunBerdiri" placeholder="Tahun Berdiri (Isikan inputan berupa angka)" value="<?php echo $TahunBerdiri; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Kelas <?php echo form_error('Kelas') ?></label> <br>
               <select name="Kelas">
                option value="Pemula">Pemula</option>
                <option value="Madya">Madya</option>
                <option value="Lanjut">Lanjut</option>
            </select>

            <!-- <input type="text" class="form-control" name="Kelas" id="Kelas" placeholder="Kelas" value="<?php echo $Kelas; ?>" /> -->
        </div>
	    <input type="hidden" name="IDKelompokTani" value="<?php echo $IDKelompokTani; ?>" />
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
	    <a href="<?php echo site_url('raw/index2') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>
