<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Produksi Hasil</h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">IDKelompokTani <?php echo form_error('IDKelompokTani') ?></label>
            <input type="text" class="form-control" name="IDKelompokTani" id="IDKelompokTani" placeholder="IDKelompokTani" readonly value="<?php echo $IDKelompokTani; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Nama <?php echo form_error('Nama') ?></label>
            <input type="text" class="form-control" name="Nama" id="Nama" placeholder="Nama" value="<?php echo $Nama; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Waktu <?php echo form_error('Waktu') ?></label>
            <input type="text" class="form-control" name="Waktu" id="Waktu" placeholder="Waktu" value="<?php echo $Waktu; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">JmlProduksi <?php echo form_error('JmlProduksi') ?></label>
            <input type="text" class="form-control" name="JmlProduksi" id="JmlProduksi" placeholder="JmlProduksi" value="<?php echo $JmlProduksi; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Satuan <?php echo form_error('Satuan') ?></label>
            <input type="text" class="form-control" name="Satuan" id="Satuan" placeholder="Satuan" value="<?php echo $Satuan; ?>" />
        </div>
	    <input type="hidden" name="IDProduksi" value="<?php echo $IDProduksi; ?>" />
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
	    <a href="<?php echo site_url('row/index5') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>
