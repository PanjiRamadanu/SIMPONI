<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Produksihasil Read</h2>
        <table class="table">
	    <tr><td>IDKelompokTani</td><td><?php echo $IDKelompokTani; ?></td></tr>
	    <tr><td>Nama</td><td><?php echo $Nama; ?></td></tr>
	    <tr><td>Waktu</td><td><?php echo $Waktu; ?></td></tr>
	    <tr><td>JmlProduksi</td><td><?php echo $JmlProduksi; ?></td></tr>
	    <tr><td>Satuan</td><td><?php echo $Satuan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('c_produksihasil') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>