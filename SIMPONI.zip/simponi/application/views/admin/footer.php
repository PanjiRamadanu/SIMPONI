<footer class="">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.4.0
  </div>
  <strong>Copyright &copy; 2014-2016 <a href="#">Almsaeed Studio</a>.</strong> All rights
  reserved.
</footer>


<!-- jQuery 3 -->
<script src="<?php echo base_url('assets/template/back/bower_components') ?>/jquery/dist/jquery.min.js"></script>


<!-- ChartJS -->
<script src="<?php echo base_url('assets/template/back/bower_components') ?>/Chart.js/Chart.js"></script>