<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Kelompoktani Read</h2>
        <table class="table">
	    <tr><td>NamaKelompokTani</td><td><?php echo $NamaKelompokTani; ?></td></tr>
	    <tr><td>Alamat</td><td><?php echo $Alamat; ?></td></tr>
	    <tr><td>RT</td><td><?php echo $RT; ?></td></tr>
	    <tr><td>Kelurahan</td><td><?php echo $Kelurahan; ?></td></tr>
	    <tr><td>Kecamatan</td><td><?php echo $Kecamatan; ?></td></tr>
	    <tr><td>Ketua</td><td><?php echo $Ketua; ?></td></tr>
	    <tr><td>JumlahAnggota</td><td><?php echo $JumlahAnggota; ?></td></tr>
	    <tr><td>TahunBerdiri</td><td><?php echo $TahunBerdiri; ?></td></tr>
	    <tr><td>Kelas</td><td><?php echo $Kelas; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('c_kelompoktani') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>