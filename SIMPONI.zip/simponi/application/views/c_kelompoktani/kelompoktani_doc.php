<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Kelompoktani List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>NamaKelompokTani</th>
		<th>Alamat</th>
		<th>RT</th>
		<th>Kelurahan</th>
		<th>Kecamatan</th>
		<th>Ketua</th>
		<th>JumlahAnggota</th>
		<th>TahunBerdiri</th>
		<th>Kelas</th>
		
            </tr><?php
            foreach ($c_kelompoktani_data as $c_kelompoktani)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $c_kelompoktani->NamaKelompokTani ?></td>
		      <td><?php echo $c_kelompoktani->Alamat ?></td>
		      <td><?php echo $c_kelompoktani->RT ?></td>
		      <td><?php echo $c_kelompoktani->Kelurahan ?></td>
		      <td><?php echo $c_kelompoktani->Kecamatan ?></td>
		      <td><?php echo $c_kelompoktani->Ketua ?></td>
		      <td><?php echo $c_kelompoktani->JumlahAnggota ?></td>
		      <td><?php echo $c_kelompoktani->TahunBerdiri ?></td>
		      <td><?php echo $c_kelompoktani->Kelas ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>