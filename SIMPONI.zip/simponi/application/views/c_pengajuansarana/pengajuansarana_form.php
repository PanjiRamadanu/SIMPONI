<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Pengajuan Sarana</h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">IDKelompokTani <?php echo form_error('IDKelompokTani') ?></label>
            <input type="text" class="form-control" name="IDKelompokTani" id="IDKelompokTani" placeholder="IDKelompokTani" readonly value="<?php echo $IDKelompokTani; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">IDKomoditasBibit <?php echo form_error('IDKomoditasBibit') ?></label>
            <input type="text" class="form-control" name="IDKomoditasBibit" id="IDKomoditasBibit" placeholder="IDKomoditasBibit" readonly value="<?php echo $IDKomoditasBibit; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">NamaBarang <?php echo form_error('NamaBarang') ?></label>
            <input type="text" class="form-control" name="NamaBarang" id="NamaBarang" placeholder="Nama Barang" value="<?php echo $NamaBarang; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Jumlah <?php echo form_error('Jumlah') ?></label>
            <input type="text" class="form-control" name="Jumlah" id="Jumlah" placeholder="Jumlah" value="<?php echo $Jumlah; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Waktu <?php echo form_error('Waktu') ?></label>
            <input type="text" class="form-control" name="Waktu" id="Waktu" placeholder="Waktu Berupa Tahun (Isikan inputan berupa angka)" value="<?php echo $Waktu; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Keterangan <?php echo form_error('Keterangan') ?></label>
            <input type="text" class="form-control" name="Keterangan" id="Keterangan" placeholder="Keterangan" value="<?php echo $Keterangan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Status <?php echo form_error('Status') ?></label>
            <input type="text" class="form-control" name="Status" id="Status" placeholder="Diajukan"  value="Diajukan" />
        </div>
	    <input type="hidden" name="IDPSarana" value="<?php echo $IDPSarana; ?>" />
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
	    <a href="<?php echo site_url('row/index7') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>
