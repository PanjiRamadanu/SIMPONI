<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Pengajuansarana Read</h2>
        <table class="table">
	    <tr><td>IDKelompokTani</td><td><?php echo $IDKelompokTani; ?></td></tr>
	    <tr><td>IDKomoditasBibit</td><td><?php echo $IDKomoditasBibit; ?></td></tr>
	    <tr><td>NamaBarang</td><td><?php echo $NamaBarang; ?></td></tr>
	    <tr><td>Jumlah</td><td><?php echo $Jumlah; ?></td></tr>
	    <tr><td>Waktu</td><td><?php echo $Waktu; ?></td></tr>
	    <tr><td>Keterangan</td><td><?php echo $Keterangan; ?></td></tr>
	    <tr><td>Status</td><td><?php echo $Status; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('c_pengajuansarana') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>