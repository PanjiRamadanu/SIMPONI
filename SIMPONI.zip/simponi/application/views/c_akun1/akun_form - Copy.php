<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Akun <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">IDKelompokTani <?php echo form_error('IDKelompokTani') ?></label>
            <input type="text" class="form-control" name="IDKelompokTani" id="IDKelompokTani" placeholder="IDKelompokTani" value="<?php echo $IDKelompokTani; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Nama <?php echo form_error('Nama') ?></label>
            <input type="text" class="form-control" name="Nama" id="Nama" placeholder="Nama" value="<?php echo $Nama; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">NoTelp <?php echo form_error('NoTelp') ?></label>
            <input type="text" class="form-control" name="NoTelp" id="NoTelp" placeholder="NoTelp" value="<?php echo $NoTelp; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Username <?php echo form_error('Username') ?></label>
            <input type="text" class="form-control" name="Username" id="Username" placeholder="Username" value="<?php echo $Username; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Password <?php echo form_error('Password') ?></label>
            <input type="text" class="form-control" name="Password" id="Password" placeholder="Password" value="<?php echo $Password; ?>" />
        </div>
	    <input type="hidden" name="IDAkun" value="<?php echo $IDAkun; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('c_akun') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>