<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Akun List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>IDKelompokTani</th>
		<th>Nama</th>
		<th>NoTelp</th>
		<th>Username</th>
		<th>Password</th>
		
            </tr><?php
            foreach ($c_akun_data as $c_akun)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $c_akun->IDKelompokTani ?></td>
		      <td><?php echo $c_akun->Nama ?></td>
		      <td><?php echo $c_akun->NoTelp ?></td>
		      <td><?php echo $c_akun->Username ?></td>
		      <td><?php echo $c_akun->Password ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>