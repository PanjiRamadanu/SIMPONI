<!doctype html>
<html>
    <head>
        <title>SIMPONI</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Pengajuan Komoditas</h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <input type="text" class="form-control" name="IDKelompokTani" id="IDKelompokTani" placeholder="IDKelompokTani" readonly value="<?php echo $IDKelompokTani; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">IDKomoditasBibit <?php echo form_error('IDKomoditasBibit') ?></label>

          <!--   <select name="IDKomoditasBibit">
				<option value="KB000012">KT000012</option>
				<option value="KB000013">KT000013</option>
			</select>
 -->
            <input type="text" class="form-control" name="IDKomoditasBibit" id="IDKomoditasBibit" placeholder="IDKomoditasBibit" readonly value="<?php echo $IDKomoditasBibit; ?>"/>
        </div>
	    <div class="form-group">
            <label for="varchar">Nama <?php echo form_error('Nama') ?></label>
            <input type="text" class="form-control" name="Nama" id="Nama" placeholder="Nama Komoditas" value="<?php echo $Nama; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Waktu <?php echo form_error('Waktu') ?></label>
            <input type="text" class="form-control" name="Waktu" id="Waktu" placeholder="Waktu Berupa Tahun (Isikan inputan berupa angka)" value="<?php echo $Waktu; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">JmlProduksi <?php echo form_error('JmlProduksi') ?></label>
            <input type="text" class="form-control" name="JmlProduksi" id="JmlProduksi" placeholder="Jumlah Produksi (Isikan berupa angka)" value="<?php echo $JmlProduksi; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Satuan <?php echo form_error('Satuan') ?></label> <br>
            <select name="Satuan">
				<option value="Ha">Ha</option>
                <option value="Meter">Meter</option>
			</select>

<!-- tutorial -->
<!-- https://www.duniailkom.com/tutorial-form-html-fungsi-dan-cara-penggunaan-tag-select-form-html/ -->
            <!-- <input type="text" class="form-control" name="Satuan" id="Satuan" placeholder="Satuan" value="<?php echo $Satuan; ?>" /> -->
        </div>
	    <input type="hidden" name="IDPKomoditas" value="<?php echo $IDPKomoditas; ?>" />
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
	    <a href="<?php echo site_url('row/index4') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>
