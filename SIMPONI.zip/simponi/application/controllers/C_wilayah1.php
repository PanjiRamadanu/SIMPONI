<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class C_wilayah1 extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_wilayah1');
        $this->load->library('form_validation');
	$this->load->library('datatables');
    }


    public function read($id)
    {
        $row = $this->M_wilayah1->get_by_id($id);
        if ($row) {
            $data = array(
		'IDWilayah' => $row->IDWilayah,
		'IDKomoditasBibit' => $row->IDKomoditasBibit,
		'IDKelompokTani' => $row->IDKelompokTani,
		'Kepemilikan' => $row->Kepemilikan,
		'Alamat' => $row->Alamat,
		'Tahun' => $row->Tahun,
		'Luas' => $row->Luas,
		'Satuan' => $row->Satuan,
	    );
            $this->load->view('C_wilayah1/wilayah_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('C_wilayah1'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('C_wilayah1/create_action'),
	    'IDWilayah' => set_value('IDWilayah'),
	    'IDKomoditasBibit' => set_value('IDKomoditasBibit'),
	    'IDKelompokTani' => set_value('IDKelompokTani'),
	    'Kepemilikan' => set_value('Kepemilikan'),
	    'Alamat' => set_value('Alamat'),
	    'Tahun' => set_value('Tahun'),
	    'Luas' => set_value('Luas'),
	    'Satuan' => set_value('Satuan'),
	);
        $this->load->view('C_wilayah1/wilayah_form', $data);
    }

    public function create_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Kepemilikan' => $this->input->post('Kepemilikan',TRUE),
		'Alamat' => $this->input->post('Alamat',TRUE),
		'Tahun' => $this->input->post('Tahun',TRUE),
		'Luas' => $this->input->post('Luas',TRUE),
		'Satuan' => $this->input->post('Satuan',TRUE),
	    );

            $this->M_wilayah1->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('row/index6'));
        }
    }

    public function update($id)
    {
        $row = $this->M_wilayah1->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('C_wilayah1/update_action'),
        'IDWilayah' => set_value('IDWilayah', $row->IDWilayah),
        'IDKomoditasBibit' => set_value('IDKomoditasBibit', $row->IDKomoditasBibit),
        'IDKelompokTani' => set_value('IDKelompokTani', $row->IDKelompokTani),
		'Kepemilikan' => set_value('Kepemilikan', $row->Kepemilikan),
		'Alamat' => set_value('Alamat', $row->Alamat),
		'Tahun' => set_value('Tahun', $row->Tahun),
		'Luas' => set_value('Luas', $row->Luas),
		'Satuan' => set_value('Satuan', $row->Satuan),
	    );
            $this->load->view('C_wilayah1/wilayah_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index6'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('IDWilayah', TRUE));
        } else {
            $data = array(
        'IDKomoditasBibit' => $this->input->post('IDKomoditasBibit',TRUE),
        'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'Kepemilikan' => $this->input->post('Kepemilikan',TRUE),
		'Alamat' => $this->input->post('Alamat',TRUE),
		'Tahun' => $this->input->post('Tahun',TRUE),
		'Luas' => $this->input->post('Luas',TRUE),
		'Satuan' => $this->input->post('Satuan',TRUE),
	    );

            $this->M_wilayah1->update($this->input->post('IDWilayah', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('row/index6'));
        }
    }

    public function delete($id)
    {
        $row = $this->M_wilayah1->get_by_id($id);

        if ($row) {
            $this->M_wilayah1->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('row/index6'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index6'));
        }
    }

    public function _rules()
    {
	$this->form_validation->set_rules('Kepemilikan', 'kepemilikan', 'trim|required');
	$this->form_validation->set_rules('Alamat', 'alamat', 'trim|required');
	$this->form_validation->set_rules('Tahun', 'tahun', 'trim|required');
	$this->form_validation->set_rules('Luas', 'luas', 'trim|required');
	$this->form_validation->set_rules('Satuan', 'satuan', 'trim|required');

	$this->form_validation->set_rules('IDWilayah', 'IDWilayah', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "wilayah.xls";
        $judul = "wilayah";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "IDKomoditasBibit");
	xlsWriteLabel($tablehead, $kolomhead++, "IDKelompokTani");
	xlsWriteLabel($tablehead, $kolomhead++, "Kepemilikan");
	xlsWriteLabel($tablehead, $kolomhead++, "Alamat");
	xlsWriteLabel($tablehead, $kolomhead++, "Tahun");
	xlsWriteLabel($tablehead, $kolomhead++, "Luas");
	xlsWriteLabel($tablehead, $kolomhead++, "Satuan");

	foreach ($this->M_wilayah1->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->IDKomoditasBibit);
	    xlsWriteLabel($tablebody, $kolombody++, $data->IDKelompokTani);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Kepemilikan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Alamat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Tahun);
	    xlsWriteNumber($tablebody, $kolombody++, $data->Luas);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Satuan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=wilayah.doc");

        $data = array(
            'wilayah_data' => $this->M_wilayah1->get_all(),
            'start' => 0
        );

        $this->load->view('C_wilayah1/wilayah_doc',$data);
    }

}

/* End of file C_wilayah1.php */
/* Location: ./application/controllers/C_wilayah1.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-04-29 16:44:39 */
/* http://harviacode.com */
