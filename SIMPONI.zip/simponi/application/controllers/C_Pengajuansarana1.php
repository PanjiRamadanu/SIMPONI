<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class C_pengajuansarana1 extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_Pengajuansarana1');
        $this->load->library('form_validation');
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('C_pengajuansarana1/pengajuansarana_list');
    }

    public function json6() {
        header('Content-Type: application/json');
        echo $this->M_Pengajuansarana1->json();
    }

    public function read($id)
    {
        $row = $this->M_Pengajuansarana1->get_by_id($id);
        if ($row) {
            $data = array(
		'IDPSarana' => $row->IDPSarana,
		'IDKelompokTani' => $row->IDKelompokTani,
		'IDKomoditasBibit' => $row->IDKomoditasBibit,
		'NamaBarang' => $row->NamaBarang,
		'Jumlah' => $row->Jumlah,
		'Waktu' => $row->Waktu,
		'Keterangan' => $row->Keterangan,
		'Status' => $row->Status,
	    );
            $this->load->view('C_pengajuansarana1/pengajuansarana_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('C_pengajuansarana1'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('C_pengajuansarana1/create_action'),
	    'IDPSarana' => set_value('IDPSarana'),
	    'IDKelompokTani' => set_value('IDKelompokTani'),
	    'IDKomoditasBibit' => set_value('IDKomoditasBibit'),
	    'NamaBarang' => set_value('NamaBarang'),
	    'Jumlah' => set_value('Jumlah'),
	    'Waktu' => set_value('Waktu'),
	    'Keterangan' => set_value('Keterangan'),
	    'Status' => set_value('Status'),
	);
        $this->load->view('C_pengajuansarana1/pengajuansarana_form', $data);
    }

    public function create_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'IDKomoditasBibit' => $this->input->post('IDKomoditasBibit',TRUE),
		'NamaBarang' => $this->input->post('NamaBarang',TRUE),
		'Jumlah' => $this->input->post('Jumlah',TRUE),
		'Waktu' => $this->input->post('Waktu',TRUE),
		'Keterangan' => $this->input->post('Keterangan',TRUE),
		'Status' => $this->input->post('Status',TRUE),
	    );

            $this->M_Pengajuansarana1->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('row/index7'));
        }
    }

    public function update($id)
    {
        $row = $this->M_Pengajuansarana1->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('C_pengajuansarana1/update_action'),
		'IDPSarana' => set_value('IDPSarana', $row->IDPSarana),
		'IDKelompokTani' => set_value('IDKelompokTani', $row->IDKelompokTani),
		'IDKomoditasBibit' => set_value('IDKomoditasBibit', $row->IDKomoditasBibit),
		'NamaBarang' => set_value('NamaBarang', $row->NamaBarang),
		'Jumlah' => set_value('Jumlah', $row->Jumlah),
		'Waktu' => set_value('Waktu', $row->Waktu),
		'Keterangan' => set_value('Keterangan', $row->Keterangan),
		'Status' => set_value('Status', $row->Status),
	    );
            $this->load->view('C_pengajuansarana1/pengajuansarana_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index7'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('IDPSarana', TRUE));
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'IDKomoditasBibit' => $this->input->post('IDKomoditasBibit',TRUE),
		'NamaBarang' => $this->input->post('NamaBarang',TRUE),
		'Jumlah' => $this->input->post('Jumlah',TRUE),
		'Waktu' => $this->input->post('Waktu',TRUE),
		'Keterangan' => $this->input->post('Keterangan',TRUE),
		'Status' => $this->input->post('Status',TRUE),
	    );

            $this->M_Pengajuansarana1->update($this->input->post('IDPSarana', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('row/index7'));
        }
    }

    public function delete($id)
    {
        $row = $this->M_Pengajuansarana1->get_by_id($id);

        if ($row) {
            $this->M_Pengajuansarana1->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('row/index7'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index7'));
        }
    }

    public function _rules()
    {
	// $this->form_validation->set_rules('IDKelompokTani', 'idkelompoktani', 'trim|required');
	// $this->form_validation->set_rules('IDKomoditasBibit', 'idkomoditasbibit', 'trim|required');
	$this->form_validation->set_rules('NamaBarang', 'namabarang', 'trim|required');
	$this->form_validation->set_rules('Jumlah', 'jumlah', 'trim|required');
	$this->form_validation->set_rules('Waktu', 'waktu', 'trim|required');
	$this->form_validation->set_rules('Keterangan', 'keterangan', 'trim|required');
	$this->form_validation->set_rules('Status', 'status', 'trim|required');

	$this->form_validation->set_rules('IDPSarana', 'IDPSarana', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "pengajuansarana.xls";
        $judul = "pengajuansarana";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "IDKelompokTani");
	xlsWriteLabel($tablehead, $kolomhead++, "IDKomoditasBibit");
	xlsWriteLabel($tablehead, $kolomhead++, "NamaBarang");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah");
	xlsWriteLabel($tablehead, $kolomhead++, "Waktu");
	xlsWriteLabel($tablehead, $kolomhead++, "Keterangan");
	xlsWriteLabel($tablehead, $kolomhead++, "Status");

	foreach ($this->M_Pengajuansarana1->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->IDKelompokTani);
	    xlsWriteLabel($tablebody, $kolombody++, $data->IDKomoditasBibit);
	    xlsWriteLabel($tablebody, $kolombody++, $data->NamaBarang);
	    xlsWriteNumber($tablebody, $kolombody++, $data->Jumlah);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Waktu);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Keterangan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Status);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=pengajuansarana.doc");

        $data = array(
            'pengajuansarana_data' => $this->M_Pengajuansarana1->get_all(),
            'start' => 0
        );

        $this->load->view('C_pengajuansarana1/pengajuansarana_doc',$data);
    }

}

/* End of file C_pengajuansarana1.php */
/* Location: ./application/controllers/C_pengajuansarana1.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-05-06 16:51:47 */
/* http://harviacode.com */
