<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class C_produksihasil1 extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_Produksihasil1');
        $this->load->library('form_validation');
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('C_produksihasil1/produksihasil_list');
    }

    public function json4() {
        header('Content-Type: application/json');
        echo $this->M_Produksihasil1->json();
    }

    public function read($id)
    {
        $row = $this->M_Produksihasil1->get_by_id($id);
        if ($row) {
            $data = array(
		'IDProduksi' => $row->IDProduksi,
		'IDKelompokTani' => $row->IDKelompokTani,
		'Nama' => $row->Nama,
		'Waktu' => $row->Waktu,
		'JmlProduksi' => $row->JmlProduksi,
		'Satuan' => $row->Satuan,
	    );
            $this->load->view('C_produksihasil1/produksihasil_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('C_produksihasil1'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('C_produksihasil1/create_action'),
	    'IDProduksi' => set_value('IDProduksi'),
	    'IDKelompokTani' => set_value('IDKelompokTani'),
	    'Nama' => set_value('Nama'),
	    'Waktu' => set_value('Waktu'),
	    'JmlProduksi' => set_value('JmlProduksi'),
	    'Satuan' => set_value('Satuan'),
	);
        $this->load->view('C_produksihasil1/produksihasil_form', $data);
    }

    public function create_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'Nama' => $this->input->post('Nama',TRUE),
		'Waktu' => $this->input->post('Waktu',TRUE),
		'JmlProduksi' => $this->input->post('JmlProduksi',TRUE),
		'Satuan' => $this->input->post('Satuan',TRUE),
	    );

            $this->M_Produksihasil1->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('row/index5'));
        }
    }

    public function update($id)
    {
        $row = $this->M_Produksihasil1->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('C_produksihasil1/update_action'),
		'IDProduksi' => set_value('IDProduksi', $row->IDProduksi),
		'IDKelompokTani' => set_value('IDKelompokTani', $row->IDKelompokTani),
		'Nama' => set_value('Nama', $row->Nama),
		'Waktu' => set_value('Waktu', $row->Waktu),
		'JmlProduksi' => set_value('JmlProduksi', $row->JmlProduksi),
		'Satuan' => set_value('Satuan', $row->Satuan),
	    );
            $this->load->view('C_produksihasil1/produksihasil_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index5'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('IDProduksi', TRUE));
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'Nama' => $this->input->post('Nama',TRUE),
		'Waktu' => $this->input->post('Waktu',TRUE),
		'JmlProduksi' => $this->input->post('JmlProduksi',TRUE),
		'Satuan' => $this->input->post('Satuan',TRUE),
	    );

            $this->M_Produksihasil1->update($this->input->post('IDProduksi', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('row/index5'));
        }
    }

    public function delete($id)
    {
        $row = $this->M_Produksihasil1->get_by_id($id);

        if ($row) {
            $this->M_Produksihasil1->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('row/index5'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index5'));
        }
    }

    public function _rules()
    {
	// $this->form_validation->set_rules('IDKelompokTani', 'idkelompoktani', 'trim|required');
	// $this->form_validation->set_rules('Nama', 'nama', 'trim|required');
	$this->form_validation->set_rules('Waktu', 'waktu', 'trim|required');
	$this->form_validation->set_rules('JmlProduksi', 'jmlproduksi', 'trim|required');
	$this->form_validation->set_rules('Satuan', 'satuan', 'trim|required');

	$this->form_validation->set_rules('IDProduksi', 'IDProduksi', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "produksihasil.xls";
        $judul = "produksihasil";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "IDKelompokTani");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama");
	xlsWriteLabel($tablehead, $kolomhead++, "Waktu");
	xlsWriteLabel($tablehead, $kolomhead++, "JmlProduksi");
	xlsWriteLabel($tablehead, $kolomhead++, "Satuan");

	foreach ($this->M_Produksihasil1->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->IDKelompokTani);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Nama);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Waktu);
	    xlsWriteNumber($tablebody, $kolombody++, $data->JmlProduksi);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Satuan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=produksihasil.doc");

        $data = array(
            'produksihasil_data' => $this->M_Produksihasil1->get_all(),
            'start' => 0
        );

        $this->load->view('C_produksihasil1/produksihasil_doc',$data);
    }

}

/* End of file C_produksihasil1.php */
/* Location: ./application/controllers/C_produksihasil1.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-04-29 16:41:28 */
/* http://harviacode.com */
