<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class C_Akun extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_Akun');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('c_akun/akun_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->M_Akun->json();
    }

    public function read($id) 
    {
        $row = $this->M_Akun->get_by_id($id);
        if ($row) {
            $data = array(
		'IDAkun' => $row->IDAkun,
		'IDKelompokTani' => $row->IDKelompokTani,
		'Nama' => $row->Nama,
		'NoTelp' => $row->NoTelp,
		'Username' => $row->Username,
		'Password' => $row->Password,
	    );
            $this->load->view('c_akun/akun_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('c_akun/create_action'),
	    'IDAkun' => set_value('IDAkun'),
	    'IDKelompokTani' => set_value('IDKelompokTani'),
	    'Nama' => set_value('Nama'),
	    'NoTelp' => set_value('NoTelp'),
	    'Username' => set_value('Username'),
	    'Password' => set_value('Password'),
	);
        $this->load->view('c_akun/akun_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'Nama' => $this->input->post('Nama',TRUE),
		'NoTelp' => $this->input->post('NoTelp',TRUE),
		'Username' => $this->input->post('Username',TRUE),
		'Password' => $this->input->post('Password',TRUE),
	    );

            $this->M_Akun->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('row/index1'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->M_Akun->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('c_akun/update_action'),
		'IDAkun' => set_value('IDAkun', $row->IDAkun),
		'IDKelompokTani' => set_value('IDKelompokTani', $row->IDKelompokTani),
		'Nama' => set_value('Nama', $row->Nama),
		'NoTelp' => set_value('NoTelp', $row->NoTelp),
		'Username' => set_value('Username', $row->Username),
		'Password' => set_value('Password', $row->Password),
	    );
            $this->load->view('c_akun/akun_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index1'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('IDAkun', TRUE));
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'Nama' => $this->input->post('Nama',TRUE),
		'NoTelp' => $this->input->post('NoTelp',TRUE),
		'Username' => $this->input->post('Username',TRUE),
		'Password' => $this->input->post('Password',TRUE),
	    );

            $this->M_Akun->update($this->input->post('IDAkun', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('row/index1'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->M_Akun->get_by_id($id);

        if ($row) {
            $this->M_Akun->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('row/index1'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index1'));
        }
    }

    public function _rules() 
    {
	// $this->form_validation->set_rules('IDKelompokTani', 'idkelompoktani', 'trim|required');
	$this->form_validation->set_rules('Nama', 'nama', 'trim|required');
	$this->form_validation->set_rules('NoTelp', 'notelp', 'trim|required');
	$this->form_validation->set_rules('Username', 'username', 'trim|required');
	$this->form_validation->set_rules('Password', 'password', 'trim|required');

	$this->form_validation->set_rules('IDAkun', 'IDAkun', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "akun.xls";
        $judul = "akun";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "IDKelompokTani");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama");
	xlsWriteLabel($tablehead, $kolomhead++, "NoTelp");
	xlsWriteLabel($tablehead, $kolomhead++, "Username");
	xlsWriteLabel($tablehead, $kolomhead++, "Password");

	foreach ($this->M_Akun->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->IDKelompokTani);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Nama);
	    xlsWriteNumber($tablebody, $kolombody++, $data->NoTelp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Username);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Password);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=akun.doc");

        $data = array(
            'akun_data' => $this->M_Akun->get_all(),
            'start' => 0
        );
        
        $this->load->view('c_akun/akun_doc',$data);
    }

}

/* End of file C_Akun.php */
/* Location: ./application/controllers/C_Akun.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-04-22 20:50:27 */
/* http://harviacode.com */