<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class c_komoditasbibit1 extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_Komoditasbibit_model1');
        $this->load->library('form_validation');
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('c_komoditasbibit1/komoditasbibit_list');
    }

    public function json() {
        header('Content-Type: application/json');
        echo $this->M_Komoditasbibit_model1->json();
    }

    public function read($id)
    {
        $row = $this->M_Komoditasbibit_model1->get_by_id($id);
        if ($row) {
            $data = array(
		'IDKomoditasBibit' => $row->IDKomoditasBibit,
		'IDKelompokTani' => $row->IDKelompokTani,
		'NamaBibit' => $row->NamaBibit,
		'Jumlah' => $row->Jumlah,
		'Tahun' => $row->Tahun,
		'Harga' => $row->Harga,
		'Satuan' => $row->Satuan,
	    );
            $this->load->view('c_komoditasbibit1/komoditasbibit_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('c_komoditasbibit1'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('c_komoditasbibit1/create_action'),
	    'IDKomoditasBibit' => set_value('IDKomoditasBibit'),
	    'IDKelompokTani' => set_value('IDKelompokTani'),
	    'NamaBibit' => set_value('NamaBibit'),
	    'Jumlah' => set_value('Jumlah'),
	    'Tahun' => set_value('Tahun'),
	    'Harga' => set_value('Harga'),
	    'Satuan' => set_value('Satuan'),
	);
        $this->load->view('c_komoditasbibit1/komoditasbibit_form', $data);
    }

    public function create_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'NamaBibit' => $this->input->post('NamaBibit',TRUE),
		'Jumlah' => $this->input->post('Jumlah',TRUE),
		'Tahun' => $this->input->post('Tahun',TRUE),
		'Harga' => $this->input->post('Harga',TRUE),
		'Satuan' => $this->input->post('Satuan',TRUE),
	    );

            $this->M_Komoditasbibit_model1->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('row/index3'));
        }
    }

    public function update($id)
    {
        $row = $this->M_Komoditasbibit_model1->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('c_komoditasbibit1/update_action'),
		'IDKomoditasBibit' => set_value('IDKomoditasBibit', $row->IDKomoditasBibit),
		'IDKelompokTani' => set_value('IDKelompokTani', $row->IDKelompokTani),
		'NamaBibit' => set_value('NamaBibit', $row->NamaBibit),
		'Jumlah' => set_value('Jumlah', $row->Jumlah),
		'Tahun' => set_value('Tahun', $row->Tahun),
		'Harga' => set_value('Harga', $row->Harga),
		'Satuan' => set_value('Satuan', $row->Satuan),
	    );
            $this->load->view('c_komoditasbibit1/komoditasbibit_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index3'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('IDKomoditasBibit', TRUE));
        } else {
            $data = array(
		'IDKelompokTani' => $this->input->post('IDKelompokTani',TRUE),
		'NamaBibit' => $this->input->post('NamaBibit',TRUE),
		'Jumlah' => $this->input->post('Jumlah',TRUE),
		'Tahun' => $this->input->post('Tahun',TRUE),
		'Harga' => $this->input->post('Harga',TRUE),
		'Satuan' => $this->input->post('Satuan',TRUE),
	    );

            $this->M_Komoditasbibit_model1->update($this->input->post('IDKomoditasBibit', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('row/index3'));
        }
    }

    public function delete($id)
    {
        $row = $this->M_Komoditasbibit_model1->get_by_id($id);

        if ($row) {
            $this->M_Komoditasbibit_model1->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('row/index3'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index3'));
        }
    }

    public function _rules()
    {
	// $this->form_validation->set_rules('IDKelompokTani', 'idkelompoktani', 'trim|required');
	$this->form_validation->set_rules('NamaBibit', 'namabibit', 'trim|required');
	$this->form_validation->set_rules('Jumlah', 'jumlah', 'trim|required');
	$this->form_validation->set_rules('Tahun', 'tahun', 'trim|required');
	$this->form_validation->set_rules('Harga', 'harga', 'trim|required');
	$this->form_validation->set_rules('Satuan', 'satuan', 'trim|required');

	$this->form_validation->set_rules('IDKomoditasBibit', 'IDKomoditasBibit', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "komoditasbibit.xls";
        $judul = "komoditasbibit";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "IDKelompokTani");
	xlsWriteLabel($tablehead, $kolomhead++, "NamaBibit");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah");
	xlsWriteLabel($tablehead, $kolomhead++, "Tahun");
	xlsWriteLabel($tablehead, $kolomhead++, "Harga");
	xlsWriteLabel($tablehead, $kolomhead++, "Satuan");

	foreach ($this->M_Komoditasbibit_model1->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->IDKelompokTani);
	    xlsWriteLabel($tablebody, $kolombody++, $data->NamaBibit);
	    xlsWriteNumber($tablebody, $kolombody++, $data->Jumlah);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Tahun);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Harga);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Satuan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=komoditasbibit.doc");

        $data = array(
            'komoditasbibit_data' => $this->M_Komoditasbibit_model1->get_all(),
            'start' => 0
        );

        $this->load->view('c_komoditasbibit1/komoditasbibit_doc',$data);
    }

}

/* End of file c_komoditasbibit1.php */
/* Location: ./application/controllers/c_komoditasbibit1.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-04-22 20:52:20 */
/* http://harviacode.com */
