<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class c_kelompoktani1 extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_Kelompoktani_model1');
        $this->load->library('form_validation');
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('c_kelompoktani1/kelompoktani_list');
    }

    public function json1() {
        header('Content-Type: application/json');
        echo $this->M_Kelompoktani_model1->json();
    }

    public function read($id)
    {
        $row = $this->M_Kelompoktani_model1->get_by_id($id);
        if ($row) {
            $data = array(
		'IDKelompokTani' => $row->IDKelompokTani,
		'NamaKelompokTani' => $row->NamaKelompokTani,
		'Alamat' => $row->Alamat,
		'RT' => $row->RT,
		'Kelurahan' => $row->Kelurahan,
		'Kecamatan' => $row->Kecamatan,
		'Ketua' => $row->Ketua,
		'JumlahAnggota' => $row->JumlahAnggota,
		'TahunBerdiri' => $row->TahunBerdiri,
		'Kelas' => $row->Kelas,
	    );
            $this->load->view('c_kelompoktani1/kelompoktani_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('c_kelompoktani1'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('c_kelompoktani1/create_action'),
	    'IDKelompokTani' => set_value('IDKelompokTani'),
	    'NamaKelompokTani' => set_value('NamaKelompokTani'),
	    'Alamat' => set_value('Alamat'),
	    'RT' => set_value('RT'),
	    'Kelurahan' => set_value('Kelurahan'),
	    'Kecamatan' => set_value('Kecamatan'),
	    'Ketua' => set_value('Ketua'),
	    'JumlahAnggota' => set_value('JumlahAnggota'),
	    'TahunBerdiri' => set_value('TahunBerdiri'),
	    'Kelas' => set_value('Kelas'),
	);
        $this->load->view('c_kelompoktani1/kelompoktani_form', $data);
    }

    public function create_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'NamaKelompokTani' => $this->input->post('NamaKelompokTani',TRUE),
		'Alamat' => $this->input->post('Alamat',TRUE),
		'RT' => $this->input->post('RT',TRUE),
		'Kelurahan' => $this->input->post('Kelurahan',TRUE),
		'Kecamatan' => $this->input->post('Kecamatan',TRUE),
		'Ketua' => $this->input->post('Ketua',TRUE),
		'JumlahAnggota' => $this->input->post('JumlahAnggota',TRUE),
		'TahunBerdiri' => $this->input->post('TahunBerdiri',TRUE),
		'Kelas' => $this->input->post('Kelas',TRUE),
	    );

            $this->M_Kelompoktani_model1->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('row/index2'));
        }
    }

    public function update($id)
    {
        $row = $this->M_Kelompoktani_model1->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('c_kelompoktani1/update_action'),
		'IDKelompokTani' => set_value('IDKelompokTani', $row->IDKelompokTani),
		'NamaKelompokTani' => set_value('NamaKelompokTani', $row->NamaKelompokTani),
		'Alamat' => set_value('Alamat', $row->Alamat),
		'RT' => set_value('RT', $row->RT),
		'Kelurahan' => set_value('Kelurahan', $row->Kelurahan),
		'Kecamatan' => set_value('Kecamatan', $row->Kecamatan),
		'Ketua' => set_value('Ketua', $row->Ketua),
		'JumlahAnggota' => set_value('JumlahAnggota', $row->JumlahAnggota),
		'TahunBerdiri' => set_value('TahunBerdiri', $row->TahunBerdiri),
		'Kelas' => set_value('Kelas', $row->Kelas),
	    );
            $this->load->view('c_kelompoktani1/kelompoktani_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index2'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('IDKelompokTani', TRUE));
        } else {
            $data = array(
		'NamaKelompokTani' => $this->input->post('NamaKelompokTani',TRUE),
		'Alamat' => $this->input->post('Alamat',TRUE),
		'RT' => $this->input->post('RT',TRUE),
		'Kelurahan' => $this->input->post('Kelurahan',TRUE),
		'Kecamatan' => $this->input->post('Kecamatan',TRUE),
		'Ketua' => $this->input->post('Ketua',TRUE),
		'JumlahAnggota' => $this->input->post('JumlahAnggota',TRUE),
		'TahunBerdiri' => $this->input->post('TahunBerdiri',TRUE),
		'Kelas' => $this->input->post('Kelas',TRUE),
	    );

            $this->M_Kelompoktani_model1->update($this->input->post('IDKelompokTani', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('row/index2'));
        }
    }

    public function delete($id)
    {
        $row = $this->M_Kelompoktani_model1->get_by_id($id);

        if ($row) {
            $this->M_Kelompoktani_model1->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('row/index2'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('row/index2'));
        }
    }

    public function _rules()
    {
	$this->form_validation->set_rules('NamaKelompokTani', 'namakelompoktani', 'trim|required');
	$this->form_validation->set_rules('Alamat', 'alamat', 'trim|required');
	$this->form_validation->set_rules('RT', 'rt', 'trim|required');
	$this->form_validation->set_rules('Kelurahan', 'kelurahan', 'trim|required');
	$this->form_validation->set_rules('Kecamatan', 'kecamatan', 'trim|required');
	$this->form_validation->set_rules('Ketua', 'ketua', 'trim|required');
	$this->form_validation->set_rules('JumlahAnggota', 'jumlahanggota', 'trim|required');
	$this->form_validation->set_rules('TahunBerdiri', 'tahunberdiri', 'trim|required');
	$this->form_validation->set_rules('Kelas', 'kelas', 'trim|required');

	$this->form_validation->set_rules('IDKelompokTani', 'IDKelompokTani', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "kelompoktani.xls";
        $judul = "kelompoktani";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "NamaKelompokTani");
	xlsWriteLabel($tablehead, $kolomhead++, "Alamat");
	xlsWriteLabel($tablehead, $kolomhead++, "RT");
	xlsWriteLabel($tablehead, $kolomhead++, "Kelurahan");
	xlsWriteLabel($tablehead, $kolomhead++, "Kecamatan");
	xlsWriteLabel($tablehead, $kolomhead++, "Ketua");
	xlsWriteLabel($tablehead, $kolomhead++, "JumlahAnggota");
	xlsWriteLabel($tablehead, $kolomhead++, "TahunBerdiri");
	xlsWriteLabel($tablehead, $kolomhead++, "Kelas");

	foreach ($this->M_Kelompoktani_model1->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->NamaKelompokTani);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Alamat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->RT);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Kelurahan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Kecamatan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Ketua);
	    xlsWriteNumber($tablebody, $kolombody++, $data->JumlahAnggota);
	    xlsWriteLabel($tablebody, $kolombody++, $data->TahunBerdiri);
	    xlsWriteLabel($tablebody, $kolombody++, $data->Kelas);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=kelompoktani.doc");

        $data = array(
            'kelompoktani_data' => $this->M_Kelompoktani_model1->get_all(),
            'start' => 0
        );

        $this->load->view('c_kelompoktani1/kelompoktani_doc',$data);
    }

}

/* End of file c_kelompoktani1.php */
/* Location: ./application/controllers/c_kelompoktani1.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-04-22 20:51:53 */
/* http://harviacode.com */
