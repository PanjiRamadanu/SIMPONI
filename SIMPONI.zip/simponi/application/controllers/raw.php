<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Raw extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function index1()
	{
		$this->load->view('user/index1');
	}
	public function index2()
	{
		$this->load->view('user/index2');
	}
		public function index3()
	{
		$this->load->view('user/index3');
	}
	public function index4()
{
	$this->load->view('user/index4');
}
public function index5()
{
	$this->load->view('user/index5');
}
public function index6()
{
	$this->load->view('user/index6');
}
public function index7()
{
	$this->load->view('user/index7');
}
public function index8()
{
	$this->load->view('user/index8');
}
	// akun
	function __construct()
    {
        parent::__construct();
        $this->load->model('M_Akun');
	    $this->load->model('M_Kelompoktani_model1');
	    $this->load->model('M_Komoditasbibit_model1');
		$this->load->model('M_Pengajuankomoditas1');
		$this->load->model('M_Produksihasil1');
		$this->load->model('M_wilayah1');
		$this->load->model('M_Pengajuansarana1');
        $this->load->library('form_validation');
		$this->load->library('datatables');
    }

    public function json() {
        header('Content-Type: application/json');
        echo $this->M_Akun->json();
    }

    public function json1() {
        header('Content-Type: application/json');
        echo $this->M_Kelompoktani_model1->json1();
    }

		public function json2() {
        header('Content-Type: application/json');
        echo $this->M_Komoditasbibit_model1->json2();
    }

		public function json3() {
        header('Content-Type: application/json');
        echo $this->M_Pengajuankomoditas1->json3();
    }

		public function json4() {
        header('Content-Type: application/json');
        echo $this->M_Produksihasil1->json4();
    }
	public function json5() {
        header('Content-Type: application/json');
        echo $this->M_wilayah1->json5();
    }

		public function json6() {
        header('Content-Type: application/json');
        echo $this->M_Pengajuansarana1->json6();
    }


}
