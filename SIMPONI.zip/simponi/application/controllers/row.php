<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Row extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct()
    {
        parent::__construct();
        $this->load->model('M_Akun');
	    $this->load->model('M_Kelompoktani_model');
	    $this->load->model('M_Komoditasbibit_model');
		$this->load->model('M_Pengajuankomoditas');
		$this->load->model('M_Produksihasil');
		$this->load->model('M_wilayah');
		$this->load->model('M_Pengajuansarana');
        $this->load->library('form_validation');
		$this->load->library('datatables');
		$this->load->model('m_grafik');
    }
	public function index1()
	{
		$this->load->view('admin/index1');
	}
	public function index2()
	{
		$this->load->view('admin/index2');
	}
		public function index3()
	{
		$this->load->view('admin/index3');
	}
	public function index4()
	{
		$this->load->view('admin/index4');
	}
	public function index5()
	{
		$this->load->view('admin/index5');
	}
	public function index6()
	{
		$this->load->view('admin/index6');
	}
	public function index7()
	{
		$this->load->view('admin/index7');
	}
	public function index8()
	{
		$this->load->view('admin/index8');
	}

	// grafik
	public function grafik1()
	{
		$x['data']=$this->m_grafik->get_data_grafik();
		$this->load->view('admin/grafik1',$x);
	}
	public function grafik2()
	{
		$y['data']=$this->m_grafik->get_data_grafik2();
		$this->load->view('admin/grafik2',$y);
	}
		public function grafik3()
	{
		$z['data']=$this->m_grafik->get_data_grafik3();
		$this->load->view('admin/grafik3',$z);
	}
	
	

    public function json() {
        header('Content-Type: application/json');
        echo $this->M_Akun->json();
    }

    public function json1() {
        header('Content-Type: application/json');
        echo $this->M_Kelompoktani_model->json1();
    }

		public function json2() {
        header('Content-Type: application/json');
        echo $this->M_Komoditasbibit_model->json2();
    }

		public function json3() {
        header('Content-Type: application/json');
        echo $this->M_Pengajuankomoditas->json3();
    }

		public function json4() {
        header('Content-Type: application/json');
        echo $this->M_Produksihasil->json4();
    }
	public function json5() {
        header('Content-Type: application/json');
        echo $this->M_wilayah->json5();
    }

		public function json6() {
        header('Content-Type: application/json');
        echo $this->M_Pengajuansarana->json6();
    }


}
