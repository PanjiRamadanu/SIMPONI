<?php
class M_grafik extends CI_Model{

	function get_data_grafik(){
        $query = $this->db->query("SELECT NamaBibit,SUM(Jumlah) AS Jumlah FROM komoditasbibit GROUP BY NamaBibit");
         
        if($query->num_rows() > 0){
            foreach($query->result() as $data){
                $hasil[] = $data;
            }
            return $hasil;
        }
    }

        function get_data_grafik2(){
        $query = $this->db->query("SELECT NamaKelompokTani,SUM(JumlahAnggota) AS JumlahAnggota FROM kelompoktani GROUP BY NamaKelompokTani");
         
        if($query->num_rows() > 0){
            foreach($query->result() as $data){
                $hasil[] = $data;
            }
            return $hasil;
        }
    }

        function get_data_grafik3(){
        $query = $this->db->query("SELECT Nama,SUM(JmlProduksi) AS JmlProduksi FROM produksihasil GROUP BY Nama");
         
        if($query->num_rows() > 0){
            foreach($query->result() as $data){
                $hasil[] = $data;
            }
            return $hasil;
        }
    }






}
